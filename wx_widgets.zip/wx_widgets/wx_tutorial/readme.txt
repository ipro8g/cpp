g++ main.cpp main.h simple.cpp simple.h  `wx-config --cxxflags --libs` -o simple



for run it in unix like os

./simple

