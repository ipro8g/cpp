#include <wx/string.h>

int main(int argc, char **argv){

  wxPuts(wxT("A wxWidgets console application"));
}
