#include <wx/wx.h>

class FlexGridSizer:public wxFrame{

	public:
		FlexGridSizer(const wxString& title);
};
