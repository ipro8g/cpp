#include <wx/wx.h>

class GotoClass:public wxFrame{

	public:
		GotoClass(const wxString& title);
};
