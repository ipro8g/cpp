#include <wx/wx.h>

class Border:public wxFrame{

	public:
		Border(const wxString& title);
};
