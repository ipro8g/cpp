#include <wx/wx.h>

class Align:public wxFrame{

	public:
		Align(const wxString& title);
};
