#include <wx/string.h>

int main(int argc, char **argv){

    wxString str = wxT("the history of my life");
    
    if(str.Contains(wxT("history"))){
    
        wxPuts(wxT("It contains!\n\n"));
    }
    
    if(!str.Contains(wxT("plain"))){
    
        wxPuts(wxT("It does NOT contains!"));
    }
}
