#include <wx/string.h>

int main(int argc, char **argv){

  wxString str = wxT("The History Of My Life");
  
  wxPuts(str.MakeLower());
  wxPuts(str.MakeUpper());
}
