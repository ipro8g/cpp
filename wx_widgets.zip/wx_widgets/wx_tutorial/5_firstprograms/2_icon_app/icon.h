#include <wx/wx.h>

class Icon : public wxFrame{

public:
	Icon(const wxString& title);
};
