#include <glib.h>
#include <glib/gstdio.h>

int main() {

g_mkdir("/home/vronskij/test", S_IRWXU);

}
