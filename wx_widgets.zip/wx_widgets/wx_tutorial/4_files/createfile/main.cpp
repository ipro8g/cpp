#include <wx/file.h>

int main(int argc, char **argv){

    wxString str = wxT("you make me want to be a better man.");
    
    wxFile file;
    file.Create(("quote"), true);
    
    if(file.IsOpened()){
        
        wxPuts(wxT("the file is opened"))
    }
    
    file.Write(str);
    file.Close();
    
    if(!file.IsOpened()){
    
        wxPuts(wxT("the file is not opened"));
    }
}
