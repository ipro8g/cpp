#include <wx/string.h>
#include <wx/utils.h>

int main(int argc, char **argv){

    wxShell(wxT("ls -l"));  
}
