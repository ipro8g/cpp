#include <wx/wx.h>
#include <wx/dnd.h>

class TextDrop : public wxFrame
{
public:
  TextDrop(const wxString& title);
    
  void OnSelect(wxCommandEvent& event);
  void OnDragInit(wxListEvent& event);

  wxGenericDirCtrl *m_gdir;
  wxListCtrl *m_lc1;
  wxListCtrl *m_lc2;

};


class MyTextDropTarget : public wxTextDropTarget
{
public:
  MyTextDropTarget(wxTextCtrl *owner);

  virtual bool OnDropText(wxCoord x, wxCoord y, 
      const wxString& data);

  wxTextCtrl *m_owner;
 
};
