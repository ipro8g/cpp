#include <wx/wx.h>

class Ident:public wxFrame{

	public:
		Ident(const wxString& title);
};
