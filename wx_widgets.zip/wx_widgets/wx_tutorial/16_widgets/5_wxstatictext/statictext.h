#include <wx/wx.h>

class StaticText:public wxFrame{

	public:
		StaticText(const wxString& title);
};
