#include <wx/wx.h>

class ScrWindow:public wxFrame{

	public:
		ScrWindow(const wxString& title);
};
