#include <wx/wx.h>

class Staticline:public wxDialog{

	public:
		Staticline(const wxString& title);
};
