#include "main.h"
#include "staticline.h"

IMPLEMENT_APP(MyApp)

bool MyApp::OnInit(){

	Staticline *sl = new Staticline(wxT("the central europe"));
	sl->ShowModal();
	sl->Destroy();

	return true;
}
