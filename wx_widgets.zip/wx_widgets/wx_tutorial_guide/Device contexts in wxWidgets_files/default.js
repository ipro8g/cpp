'use strict';
/**
 * Run the Load the Webfont .
 */

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

Banner.prototype.webFontLoad = function (options) {
  WebFont.load(options);
  this.start();
};
/**
 * Run the animation functions.
 */


Banner.prototype.start = function () {
  var _this2 = this;

  this.dims = this.bannerWidth + 'x' + this.bannerHeight;
  this.path = this.bannerData.feed[0];
  this.locations = this.path.destinations_InputEditor_banner.split('|');
  this.prices = this.path.prices_InputEditor_banner.split('|');
  this.removeDots = false;

  if (this.locations.length == 2) {
    this.removeDots = true;
    this.locations.push(this.locations[0]);
    this.locations.push(this.locations[1]);
    this.prices.push(this.prices[0]);
    this.prices.push(this.prices[1]);
  }

  this.framesNum = this.locations.length;
  gsap.registerPlugin(Draggable, InertiaPlugin, CSSPlugin);
  this.images = this.getImageUrls([this.bannerData.feed[0].backgroundImageUrl_InputEditor_asset, this.bannerData.feed[0].image1Url_InputEditor_asset, this.bannerData.feed[0].image2Url_InputEditor_asset, this.bannerData.feed[0].image3Url_InputEditor_asset, this.bannerData.feed[0].image4Url_InputEditor_asset, this.bannerData.feed[0].logoUrl_InputEditor_asset]);
  this.preloadImages(this.images, function () {
    _this2.createElements();

    _this2.setup();

    _this2.hidePreloader();

    _this2.animate();

    _this2.bindEvents();
  });
};

Banner.prototype.getImageUrls = function (imageElementArray) {
  var urls = imageElementArray.map(function (imageElement) {
    return imageElement.hasOwnProperty('Url') ? imageElement.Url : imageElement;
  });
  return urls.filter(Boolean);
};
/**
 * Create dom elements.
 */


Banner.prototype.createElements = function () {
  var _this = this;

  var data = this.bannerData.feed[0];
  this.copyArr = [];
  this.imageArr = [];
  this.framesArr = [];
  this.navDotsArr = [];
  this.frameCopy = [];

  var isRetina = function isRetina(smartObject) {
    if (smartObject.hasOwnProperty('retina')) {
      return smartObject.retina.toLowerCase() == 'true' ? true : false;
    } else {
      return false;
    }
  };

  this.bgColor = this.smartObject({
    id: 'backgroundColor_ColorEditor_asset',
    width: this.bannerWidth,
    height: this.bannerHeight,
    backgroundColor: this.bannerData.feed[0].backgroundColor_ColorEditor_asset,
    parent: this.banner
  });
  this.bgImage = this.smartObject(_objectSpread(_objectSpread({
    id: 'backgroundImage_InputEditor_asset',
    backgroundImage: this.bannerData.feed[0].backgroundImageUrl_InputEditor_asset.hasOwnProperty('Url') ? this.bannerData.feed[0].backgroundImageUrl_InputEditor_asset.Url : this.bannerData.feed[0].backgroundImageUrl_InputEditor_asset
  }, this.bannerData.feed[0].backgroundImageStyle_InputEditor_asset), {}, {
    retina: isRetina(this.bannerData.feed[0].backgroundImageStyle_InputEditor_asset),
    parent: this.banner
  }));
  this.logo = this.smartObject(_objectSpread(_objectSpread({
    id: 'logoStyle_InputEditor_asset',
    backgroundImage: this.bannerData.feed[0].logoUrl_InputEditor_asset.hasOwnProperty('Url') ? this.bannerData.feed[0].logoUrl_InputEditor_asset.Url : this.bannerData.feed[0].logoUrl_InputEditor_asset
  }, this.bannerData.feed[0].logoStyle_InputEditor_asset), {}, {
    retina: isRetina(this.bannerData.feed[0].logoStyle_InputEditor_asset),
    parent: this.banner
  })); ////CAROUSEL

  this.wrapper = this.smartObject(_objectSpread(_objectSpread({
    id: 'shape1_InputEditor_asset'
  }, data.shape1_InputEditor_asset), {}, {
    parent: this.banner
  }));
  this.mask = this.smartObject(_objectSpread(_objectSpread({
    id: 'shape2_InputEditor_asset'
  }, data.shape2_InputEditor_asset), {}, {
    parent: this.wrapper
  }));
  this.hit = this.smartObject({
    id: 'hit',
    width: 10,
    height: this.bannerHeight,
    parent: this.mask
  });

  for (var q = 0; q <= this.framesNum - 1; q++) {
    this["frame" + q] = this.smartObject(_objectSpread(_objectSpread({
      id: "FRAME" + q
    }, data.shape3_InputEditor_asset), {}, {
      parent: this.mask
    }));
    this.framesArr.push(this["frame" + q]);
    this["gridD" + q] = this.smartObject(_objectSpread(_objectSpread({
      id: 'textGrid4_InputEditor_text'
    }, data.textGrid4_InputEditor_text), {}, {
      parent: this["frame" + q]
    }));
    this["gridA" + q] = this.smartObject(_objectSpread(_objectSpread({
      id: 'textGrid1_InputEditor_text'
    }, data.textGrid1_InputEditor_text), {}, {
      parent: this["frame" + q]
    }));
    this["location" + q] = this.smartObject(_objectSpread(_objectSpread(_objectSpread({
      id: "copy1_InputEditor_text"
    }, data.textStyle1_InputEditor_text), data.copy1_InputEditor_text), {}, {
      innerHTML: this.locations[q],
      // parent: this[`gridA${q}`],
      parent: this.path["copy1_InputEditor_text"].hasOwnProperty('parent') ? this[this.path["copy1_InputEditor_text"].parent + q] : this["gridA" + q]
    }));
    this["extraCopy" + q] = this.smartObject(_objectSpread(_objectSpread(_objectSpread({
      id: "copy5_InputEditor_text"
    }, data.textStyle1_InputEditor_text), data.copy5_InputEditor_text), {}, {
      parent: this["gridA" + q]
    }));
    this["gridB" + q] = this.smartObject(_objectSpread(_objectSpread({
      id: 'textGrid2_InputEditor_text'
    }, data.textGrid2_InputEditor_text), {}, {
      parent: this["gridA" + q]
    }));
    this["gridC" + q] = this.smartObject(_objectSpread(_objectSpread({
      id: 'textGrid3_InputEditor_text'
    }, data.textGrid3_InputEditor_text), {}, {
      parent: this["gridB" + q]
    }));
    var copy2Parent = data.copy2_InputEditor_text.parent ? this["" + data.copy2_InputEditor_text.parent + q] : this["gridC" + q];
    this["from" + q] = this.smartObject(_objectSpread(_objectSpread(_objectSpread(_defineProperty({
      id: "FROM" + q
    }, "id", 'copy2_InputEditor_text'), data.textStyle1_InputEditor_text), data.copy2_InputEditor_text), {}, {
      parent: copy2Parent
    }));
    var copy3Parent = data.copy3_InputEditor_text.parent ? this["" + data.copy3_InputEditor_text.parent + q] : this["gridC" + q];
    this["currency" + q] = this.smartObject(_objectSpread(_objectSpread(_objectSpread({
      id: "copy3_InputEditor_text"
    }, data.textStyle1_InputEditor_text), data.copy3_InputEditor_text), {}, {
      innerHTML: data.currency_InputEditor_banner,
      parent: copy3Parent
    }));
    var copy4Parent = data.copy4_InputEditor_text.parent ? this["" + data.copy4_InputEditor_text.parent + q] : this["gridB" + q];
    this["price" + q] = this.smartObject(_objectSpread(_objectSpread(_objectSpread({
      id: "copy4_InputEditor_text"
    }, data.textStyle1_InputEditor_text), data.copy4_InputEditor_text), {}, {
      innerHTML: this.prices[q],
      parent: copy4Parent
    }));
    this.frameCopy.push(this["price" + q], this["currency" + q], this["from" + q], this["extraCopy" + q], this["location" + q]);
  }

  ; ////CAROUSEL END

  this.navBar = this.smartObject(_objectSpread(_objectSpread({
    id: 'shape4_InputEditor_asset'
  }, data.shape4_InputEditor_asset), {}, {
    parent: this.wrapper
  })); ///CRETE DOTS 

  var numDots = this.removeDots == true ? 2 : this.locations.length;

  for (var g = 0; g < numDots; g++) {
    this["dot" + g] = this.smartObject(_objectSpread(_objectSpread({
      id: "DOT" + g
    }, data.shape5_InputEditor_asset), {}, {
      parent: this.navBar
    }));
    this.navDotsArr.push(this["dot" + g]);
  }

  if (this.framesNum == 1) {
    gsap.set(this.navBar, {
      display: 'none'
    });
  }

  ;

  for (var k = 1; k <= 4; k++) {
    this["image" + k] = this.smartObject(_objectSpread(_objectSpread({
      id: "image" + k + "_InputEditor_asset",
      backgroundImage: this.path["image" + k + "Url_InputEditor_asset"].hasOwnProperty('Url') ? this.path["image" + k + "Url_InputEditor_asset"].Url : this.path["image" + k + "Url_InputEditor_asset"]
    }, this.path["image" + k + "Style_InputEditor_asset"]), {}, {
      retina: isRetina(this.path["image" + k + "Style_InputEditor_asset"]),
      parent: this.banner
    })); // this.imageArr.push(this[`image${k}`]);
  }

  this.textGrid5 = this.smartObject(_objectSpread(_objectSpread({
    id: 'textGrid5_InputEditor_text'
  }, this.path.textGrid5_InputEditor_text), {}, {
    parent: this.banner
  }));

  for (var h = 6; h <= 10; h++) {
    this["copy" + h] = this.smartObject(_objectSpread(_objectSpread(_objectSpread({
      id: "copy" + h + "_InputEditor_text",
      className: 'text-extra',
      innerHTML: data["copy" + h + "_InputEditor_text"].innerHTML
    }, data.textStyle1_InputEditor_text), data["copy" + h + "_InputEditor_text"]), {}, {
      parent: this.path["copy" + h + "_InputEditor_text"].hasOwnProperty('parent') ? this[this.path["copy" + h + "_InputEditor_text"].parent] : this.banner
    }));
    this.copyArr.push(this["copy" + h]);
  }

  this.cta = this.smartObject(_objectSpread(_objectSpread({
    id: 'ctaStyle_InputEditor_text'
  }, this.path.ctaStyle_InputEditor_text), {}, {
    parent: this.banner
  }));
  this.exit = this.smartObject({
    id: 'EXIT',
    top: 0,
    zIndex: 200,
    width: this.bannerWidth,
    height: this.bannerHeight,
    parent: this.banner
  });
};
/**
 * Setup initial element states.
 */


Banner.prototype.setup = function () {
  this.frameID = 0;
  gsap.set(this.navBar.firstChild, {
    backgroundColor: this.bannerData.feed[0].shape5_InputEditor_asset.selectedColor,
    border: this.bannerData.feed[0].shape5_InputEditor_asset.selectedBorder
  });
};
/**
 * Hide the preloader.
 */


Banner.prototype.hidePreloader = function () {
  gsap.to('.preloader', 1, {
    autoAlpha: 0
  });
};
/**
 * Animation timeline.
 */


Banner.prototype.animate = function () {
  var _this3 = this;

  var numSlides = this.framesArr.length;
  var slideDuration = Number(this.bannerData.feed[0].shape1_InputEditor_asset.slideDuration) || 1;
  var delayTimer = numSlides > 1 ? numSlides * slideDuration : 4;
  var endFrameDelay = Number(this.bannerData.feed[0].shape1_InputEditor_asset.buildDelay) || delayTimer;
  this.timeline = gsap.timeline({
    paused: false,
    delay: endFrameDelay,
    onStart: function onStart() {
      if (_this3.timer) _this3.timer.kill();
    }
  }).add('ef', 0.2).from(this.image1, {
    duration: 0.5,
    autoAlpha: 0
  }, 'ef').to([this.wrapper, this.navBar], {
    duration: 0.5,
    autoAlpha: 0
  }, 'ef').from(this.copy6, {
    duration: 0.5,
    y: '+=10',
    autoAlpha: 0
  }).from(this.copy7, {
    duration: 0.5,
    y: '+=10',
    autoAlpha: 0
  }).from(this.copy8, {
    duration: 0.5,
    y: '+=10',
    autoAlpha: 0
  }).call(function () {
    if (_this3.timer) _this3.timer.kill();
  });

  if (numSlides > 1) {
    var updateDraggable = function updateDraggable() {};

    var animateSlides = function animateSlides(direction) {
      _this.timer.restart(true);

      var x = snapX(gsap.getProperty(proxy, "x") + direction * slideWidth);
      console.log('direction: ', direction);
      slideAnimation = gsap.to(proxy, {
        duration: slideDuration,
        x: x,
        ease: "sine.inOut",
        onUpdate: updateProgress
      });
    };

    var autoPlay = function autoPlay() {
      if (_this.draggable.isPressed || _this.draggable.isDragging || _this.draggable.isThrowing) {
        _this.timer.restart(true);
      } else {
        animateSlides(-1);
      }
    };

    var updateProgress = function updateProgress() {
      animation.progress(gsap.utils.wrap(0, 1, gsap.getProperty(proxy, "x") / wrapWidth));
    };

    var snapX = function snapX(x) {
      return Math.round(x / slideWidth) * slideWidth;
    };

    // gsap.set(this.navBar, {display: 'none'})
    var slideDelay = Number(this.bannerData.feed[0].shape1_InputEditor_asset.frameDelay);
    var buildDelay = Number(this.bannerData.feed[0].shape1_InputEditor_asset.buildDelay) || 0.5;
    var proxy = document.createElement("div");
    var slideAnimation = gsap.to({}, {
      duration: 0.1
    });
    var slideWidth = Number(this.bannerData.feed[0].shape3_InputEditor_asset.width) + Number(this.bannerData.feed[0].shape1_InputEditor_asset.gap);
    var pGap = Number(this.bannerData.feed[0].shape1_InputEditor_asset.gap) * 100 / Number(this.bannerData.feed[0].shape3_InputEditor_asset.width);
    var wrapWidth = slideWidth * numSlides;
    this.timer = gsap.delayedCall(slideDelay, autoPlay);

    for (var i = 0; i < numSlides; i++) {
      gsap.set(this.framesArr[i], {
        xPercent: i * (100 + pGap)
      });
    }

    var _this = this;

    var fakeDotArray = [0, 1, 0, 1];
    var animation = gsap.to(this.framesArr, {
      duration: 1,
      xPercent: "+=" + numSlides * (100 + pGap),
      ease: "none",
      paused: true,
      modifiers: {
        xPercent: gsap.utils.wrap(-(100 + pGap), (numSlides - 1) * (100 + pGap))
      },
      onUpdate: function onUpdate() {
        for (var i = 0; i < _this.framesArr.length; i++) {
          if (Draggable.hitTest(_this.framesArr[i], _this.hit)) {
            var string = _this.framesArr[i].id;
            var frame = string.match(/\d+/g).map(Number)[0];

            if (_this.removeDots == true) {
              frame = fakeDotArray[frame];
            }

            _this.frameID = frame;
            console.log(frame);
            gsap.set(_this.navBar.childNodes, {
              backgroundColor: _this.bannerData.feed[0].shape5_InputEditor_asset.backgroundColor,
              border: _this.bannerData.feed[0].shape5_InputEditor_asset.border
            });
            gsap.set(_this["dot" + frame], {
              backgroundColor: _this.bannerData.feed[0].shape5_InputEditor_asset.selectedColor,
              border: _this.bannerData.feed[0].shape5_InputEditor_asset.selectedBorder
            });
          }
        }
      }
    });
    gsap.set(proxy, {
      x: 0
    });
    this.draggable = new Draggable(proxy, {
      trigger: this.wrapper,
      throwProps: true,
      allowEventDefault: true,
      onPress: updateDraggable,
      onDrag: updateProgress,
      onThrowUpdate: updateProgress,
      onDragEnd: function onDragEnd() {
        Enabler.counter('swipe', true);
      },
      snap: {
        x: gsap.utils.snap(slideWidth)
      }
    });
    ;
    this.navDotsArr.forEach(function (button, index) {
      button.addEventListener('click', function () {
        console.log('Button ID: ', index);
        console.log('Current Frame: ', _this.frameID);

        if (index !== _this.frameID) {
          var moveBy = index - _this.frameID;
          animateSlides(moveBy * -1);
        }
      });
    });
  }
};
/**
 * Setup preview data element states.
 */


Banner.prototype.setupPreview = function (targetId, settings) {
  var _settings = settings;
  console.log(targetId);
  console.log(settings);

  if (targetId == 'logo_InputEditor_asset') {
    if (settings.hasOwnProperty('backgroundImage')) {
      _settings.backgroundImage = this.getImagePath(settings.backgroundImage);
      gsap.set(this.logo, {
        backgroundImage: 'url(' + _settings.backgroundImage + ')'
      });
    } else {
      gsap.set(this.logo, _settings);
    }
  }

  if (targetId == 'backgroundImage_InputEditor_asset') {
    if (settings.hasOwnProperty('backgroundImage')) {
      _settings.backgroundImage = this.getImagePath(settings.backgroundImage);
      gsap.set(this.bgImage, {
        backgroundImage: 'url(' + _settings.backgroundImage + ')'
      });
    } else {
      gsap.set(this.bgImage, _settings);
    }
  }

  if (targetId == 'textStyle1_InputEditor_text') {
    gsap.set(this.frameCopy, _settings);
  } else {
    gsap.set("#" + targetId, _settings);
  }
};